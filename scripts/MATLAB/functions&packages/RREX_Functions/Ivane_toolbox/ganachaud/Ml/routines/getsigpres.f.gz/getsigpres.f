      subroutine getsigpres(nd,np,ns,pres,botdep,imaxd,sigs,sigint,
     &     psig)
c
c synopsis :
 
c  depths must be positive (Pressure)
c

c description : 
 
c   find the depth of the isopycnals in sigint by linear interpolation
c   of the sigma values contained in sigs. 
c   sigs and sigint are relative to the same pressure reference
c   If above the surface, depth is zero
c   If under last standard depth, depth is extrapolated
c   If under bottom, depth is bottom depth.
c
c INPUTS
c   nd          : number of standard depths
c   np          : number of pairs
c   ns          : number of interfaces
c   pres(nd)    : pressure array (depth, db)
c   botdep(np)  : bottom depth
c   imaxd(np)   : max standard depth index, before bottom
c   sigs(nd,np) : sigma values at each point on the std grid, 
c                 -1 under bottom
c   sigint(ns)  : sigma interface values

c OUTPUTS (I/O)
c   psig(np,ns) : pressure value for each interface
c

c uses :

c side effects : if we are outside the data range 
c                sigprop is linearily extrapolated

c author : A.Ganachaud, Jan 97

c reference :
c   same as Alison's routine set_bdata, except that the bottom
c   pressure is the actual bottom rather than the last standard
c   depth

c see also :

cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc

      integer*4 nd,np,ns
      integer*4 imaxd(np)
      real*8    pres(nd),botdep(np),sigint(ns)
      real*8    sigs(nd,np)
      real*8    psig(np,ns)

      real      botsig,xsig
      integer   id,ip,is,lsd
c     indices: id = depth indices
c              ip = pair indices
c              is = sigma-layer indices

         
c     FOR EACH PAIR
      do ip=1,np
c        FOR EACH LAYER INTERFACE
         do is=1,ns
            
            xsig=sigint(is)
c           IF ABOVE THE SURFACE, SET TO THE SURFACE
            if (xsig.le.sigs(1,ip)) then
               psig(ip,is)=pres(1)
            else
c             FIND SURROUNDING STANDARD DEPTHS
               do id=1,nd
                  if (xsig.le.sigs(id,ip)) then
                     goto 100
                  endif
               enddo
 100           continue
               if (id.eq.1) then   
c                 sigma at the surface
                  if (sigs(2,ip).lt.0) then
                     psig(ip,is)=pres(1) + (xsig-sigs(1,ip))*
     &                    (pres(2)-pres(1))/
     &                    (sigs(2,ip)-sigs(1,ip))
      
                  else 
c                    THERE IS ONLY ONE POINT
                     psig(ip,is)=pres(1)
                  endif

               else if ((id.eq.(nd+1)).or.(sigs(id,ip).lt.0)) then
c                 EXTRAPOLATE SIGMA AT THE BOTTOM
                  lsd=imaxd(ip)
                  botsig=sigs(lsd,ip) + (botdep(ip)-pres(lsd))*
     &                 (sigs(lsd,ip)-sigs(lsd-1,ip))/
     &                 (pres(lsd)-pres(lsd-1))
                  if (xsig.ge.botsig) then
C                    THE PSIG TAKES THE BOTTOM DEPTH VALUE
                     psig(ip,is)=botdep(ip)
                  else
c                    INTERPOLATES BETWEEN BOTTOM SIGMA AND LSD
                     psig(ip,is)=(pres(lsd)*(botsig-xsig) -
     &                    botdep(ip)*(sigs(lsd,ip)-xsig))/
     &                    (botsig-sigs(lsd,ip))
                  endif
               else                
c                 REGULAR INTERPOLATION
                  psig(ip,is)=(pres(id-1)*(sigs(id,ip)-xsig) -
     &                 pres(id)*(sigs(id-1,ip)-xsig))/
     &                 (sigs(id,ip)-sigs(id-1,ip))
               
               endif
            endif

         enddo                  
c        LOOP ON INTERFACE
      enddo                  
c     LOOP ON EACH PAIR


      return
      end
